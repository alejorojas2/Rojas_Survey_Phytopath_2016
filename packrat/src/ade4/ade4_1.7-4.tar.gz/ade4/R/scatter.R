############ scatter #################
"scatter" <- function (x, ...) UseMethod("scatter")
